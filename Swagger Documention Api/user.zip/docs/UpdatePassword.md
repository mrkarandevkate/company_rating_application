# UpdatePassword

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | Email of the user whose password needs to be updated |  [optional]
**password** | **String** | The new password for the user |  [optional]
