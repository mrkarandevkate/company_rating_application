# UserIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **Integer** |  |  [optional]
