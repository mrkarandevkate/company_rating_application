# RatingIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ratingId** | **Integer** | The unique identifier of the newly added rating. |  [optional]
