# RatingIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ratingId** | **Float** | The unique identifier of the newly added rating. |  [optional]
