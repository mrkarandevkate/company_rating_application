# Company

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyId** | **Integer** |  |  [optional]
**companyName** | **String** |  |  [optional]
**industry** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**createdAt** | **Object** |  |  [optional]
**imagePath** | **String** | The path to the company&#x27;s image |  [optional]
