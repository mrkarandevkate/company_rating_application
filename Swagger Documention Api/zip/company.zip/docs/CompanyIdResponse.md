# CompanyIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyId** | **Integer** |  |  [optional]
