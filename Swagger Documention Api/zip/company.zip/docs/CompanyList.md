# CompanyList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
