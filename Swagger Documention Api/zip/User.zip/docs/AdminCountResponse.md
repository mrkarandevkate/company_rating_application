# AdminCountResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adminCount** | **Integer** |  |  [optional]
